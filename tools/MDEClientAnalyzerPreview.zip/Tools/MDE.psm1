﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.194
	 Created on:   	10/19/2021 3:50 PM
	 Created by:   	ksarens
	 Updated 10/26/2102
	 	fixing error in help information
	 	adding support for offline scenarios
	 Organization: 	
	 Filename:     	MDEHelper.psm1
	===========================================================================
	.DESCRIPTION
		Helper functions for MDE Support solutions
#>

function checkEPPVersion
{
	<#
.SYNOPSIS
	Supportability of Defender EPP components
.DESCRIPTION
    Returns if the provided version of a component (MoCAMP, Engine, Sigs) is lower than the version online and no longer supported
.PARAMETER component
    The component to verify, this can be: MoCAMP|Engine|Sigs
.PARAMETER version
    The version of the component
.PARAMETER xml
    XML document containing the online versions (only needed in offline scenarios). In offline scenarios, the XML document needs to be provided, NOT the path to the xml file
.EXAMPLE
	checkEPPVersion -component MoCAMP -version 4.18.2009.6
        The result of the above example is True as this version is older than N-2 and no longer supported
.NOTES
	If there is no internet connectivity, the method will return $null, in this case provide the XML parameter (see above)
.LINK
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateSet('MoCAMP', 'Engine','Sigs')]
		[string]$component,
		[Parameter(Mandatory = $true, Position = 1)]
		[string]$version,
		[Parameter(Mandatory = $false)]
		[xml]$xml
	)
	
	Begin
	{
		$catch=$false
		if ($null -eq $script:EPP_Versions)
		{
			try {
				if($null -eq $xml)
				{
					$Response = Invoke-WebRequest -URI "https://www.microsoft.com/security/encyclopedia/adlpackages.aspx?action=info" -UseBasicParsing
					[xml]$xml = $Response.Content
				}
			}
			catch {
				$catch=$true
			}
			
			
			$script:EPP_Versions = New-Object System.Management.Automation.PSObject
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "MoCAMP" -NotePropertyValue $xml.ChildNodes[1].platform
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Engine" -NotePropertyValue $xml.ChildNodes[1].engine
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Sigs" -NotePropertyValue $xml.ChildNodes[1].signatures.'#text'
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Date" -NotePropertyValue $xml.ChildNodes[1].signatures.date
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Updated" -NotePropertyValue (Get-Date -Format "MM/dd/yyyy HH:mm")
		}
		if ($version -like "*-*")
		{
			$version = $version.split('-')[0]
		}
	}
	Process
	{
		if($catch)
		{return $null}
		Try
		{
			switch ($component)
			{
				"MoCAMP" {
					
					if ([System.version]$script:EPP_Versions.MoCAMP -gt [System.version]$version)
					{
						$online = @()
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[0]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[1]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[2]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[3]
						
						$current = @()
						$current += [int]$version.split('.')[0]
						$current += [int]$version.split('.')[1]
						$current += [int]$version.split('.')[2]
						$current += [int]$version.split('.')[3]
						if (($online[2] - $current[2]) -ge 3 -or (($online[2] - $current[2]) -gt 90 -and ($online[2] - $current[2]) -lt 92))
						{
							return $true
						}
						return $false
					}
				}
				"Sigs" {
					if ([System.version]$script:EPP_Versions.Sigs -gt [System.version]$version)
					{
						return $true
					}
				}
				"Engine" {
					if ([System.version]$script:EPP_Versions.Engine -gt [System.version]$version)
					{
						return $true
					}
				}
			}
			return $false
		}
		Catch
		{
			#Write-Log -Message "ERROR $($MyInvocation.MyCommand) [$($var)] - [$_]" -Severity 3
		}
		
	}
	End
	{
		[GC]::Collect()
	}
}
Export-ModuleMember checkEPPVersion
# SIG # Begin signature block
# MIInwwYJKoZIhvcNAQcCoIIntDCCJ7ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA9YhaHHSHxLWs4
# 82HsnJ7/cUuUmBqC+dakbmWaA9IjGKCCDZcwggYVMIID/aADAgECAhMzAAADEBr/
# fXDbjW9DAAAAAAMQMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwODA0MjAyNjM5WhcNMjMwODAzMjAyNjM5WjCBlDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjE+MDwGA1UEAxM1TWlj
# cm9zb2Z0IFdpbmRvd3MgRGVmZW5kZXIgQWR2YW5jZWQgVGhyZWF0IFByb3RlY3Rp
# b24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC0y67idUrLERDl3ls1
# 1XkmCQNGqDqXUbrM7xeQ3MDX2TI2X7/wxqqVBo5wjSGMUEUxZpgrQRj7fyyeQWvy
# OKx7cxcBYXxRWjOQRSYWqk+hcaLj7E9CkuYyM1tuVxuAehDD1jqwLGS5LfFG9iE9
# tXCQHI59kCLocKMNm2C8RWNNKlPYN0dkN/pcEIpf6L+P+GXYN76jL+k7uXY0Vgpu
# uKvUZdxukyqhYbWy8aNr8BasPSOudq2+1VzK52kbUq79M7F3lN+JfDdyiG5YoSdc
# XDrvOU1fnP1Kc4PtUJL7tSHFuBylTiNyDnHfSORQeZPFg971CeZS7I8ZFojDLgTY
# kDQDAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wv
# ATAdBgNVHQ4EFgQU0X7BWbJmeu82AxuDs7MBJC8zJ8swRQYDVR0RBD4wPKQ6MDgx
# HjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEWMBQGA1UEBRMNNDUxODk0
# KzQ3MjIyMDAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8E
# TTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBR
# BggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAw
# DQYJKoZIhvcNAQELBQADggIBAIXZp9/puv2exE6jflkfuJ3E8xrXA1ch9bnCloXS
# 01xOXTauGU/+1peumenJbgwCzn/iwGIJkuoHSx5F85n7OG9InPRApTNcYmAkGPIk
# /x5SNl67Su8eHlLGd8erjoEcseZBckRENr5mBHtELtOWR80cAH9dbALlY/gJ5FDq
# jOxA9Q6UDeaT9oeIJwSy/LD9sUKrUZ4zSvqFBjjEBx3g2TfmRe3qLfKJEOL1mzCk
# 06RHYwcU2uU1s5USCeePuafeQ159io+FVdW5f7703UeD4pzXOp4eZTtWl0875By+
# bWxAR8/dc41v2MEQoy0WplbGfkBm9BWT0w0pL3itBYcXRlzIfPForBPK2aIQOMPL
# CH8JR3uJXvbTJ5apXBAFOWl6dU1JqGTT/iuWsVznHBqDmq6zKf38QYocac0o7qL3
# RG1/eiQdbPQisNpFiqTzTd6lyUaXrPtk+BniKT4bVXJ2FrfsmLiXIcFhC6FAidok
# spWZVHS8T4WwSPVpmhjEgubZlhldva/wOT/OjtGzoy6L7yNKjcSadVou4VroLLK9
# qwYgKnjyzX8KEcGkKUXScwZIp8uWDp5bmKYh+5SQEa26bzHcX0a1iqmsUoP5JhYL
# xwloQM2AgY9AEAIHSFXfCo17ae/cxV3sEaLfuL09Z1sSQC5wm32hV3YyyEgsRDXE
# zXRCMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4
# MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3Y
# bqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUB
# FDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnbo
# MlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT
# +OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuy
# e4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEh
# NSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2
# z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3
# s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78Ic
# V9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E
# 11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5P
# M4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcV
# AQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBL
# hklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggr
# BgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsG
# AQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDB
# ZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc
# 8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYq
# wooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu
# 5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWI
# UUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXh
# j38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yH
# PgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtI
# EJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4Guzq
# N5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgR
# MiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQ
# zTGCGYIwghl+AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEC
# EzMAAAMQGv99cNuNb0MAAAAAAxAwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEIAu+b3Dxo76vP1XyJFnB7JUB+pPSFO8Gxi1g1xC2p8kh
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAZ2kNoPfRW6+0
# CHzd4lIMcfc8lFT4fdVu6q3wbsqyQ5GMhEUWM5lUCKw6sG2+VQbB2cltLi3WztPr
# NHZt8vQ/r2Jo2ID7Veno7TFhvhe3lTv9v8SbTlbCcXIEZb8E3FQOUqYnjhkv8uNB
# NxJrsUzArEfervP4vArgqfTRzVpAVj6mREmN5uVE4iMB+/rq3OJpxnwkGoESqOWh
# nmxlMlJ4/l2lISFr32ltDqak5EgsugoKz8O55koqvKPt2HNf2zw2SV3Py5LcEr/a
# ZOuW3+qB4kRGXMZitlZ1alQFCiOHDG38e4/p8j0uTPc+hC60uEGqo9PM8R3xg/mG
# yEul2uJ8RaGCFwwwghcIBgorBgEEAYI3AwMBMYIW+DCCFvQGCSqGSIb3DQEHAqCC
# FuUwghbhAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFVBgsqhkiG9w0BCRABBKCCAUQE
# ggFAMIIBPAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCDFOqTagY6P
# VCQWhP2iU6keJbm0im7ytOlMMGOs9KiNzQIGYynzQHZWGBMyMDIyMDkyODExNDkx
# Ny41MDRaMASAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8g
# UmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046ODk3QS1FMzU2LTE3MDExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WgghFfMIIHEDCCBPig
# AwIBAgITMwAAAasJCe+rY9ToqQABAAABqzANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMjAzMDIxODUxMjhaFw0yMzA1MTEx
# ODUxMjhaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkw
# JwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046ODk3QS1FMzU2LTE3MDExJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDJnUtaOXXoQElLLHC6ssdsJv1oqzVH6pBgcpgyLWMxJ6CrZIa3e8Db
# CbOIPgbjN7gV/NVpztu9JZKwtHtZpg6kLeNtE5m/JcLI0CjOphGjUCH1w66J61Td
# 2sNZcfWwH+1WRAN5BxapemADt5I0Oj37QOIlR19yVb/fJ7Y5G7asyniTGjVnfHQW
# gA90QpYjKGo0wxm8mDSk78QYViC8ifFmHSfzQQ6aj80JfqcZumWVUngUACDrm2Y1
# NL36RAsRwubyNRK66mqRvtKAYYTjfoJZVZJTwFmb9or9JoIwk4+2DSl+8i9sdk76
# 7x1auRjzWuXzW6ct/beXL4omKjH9UWVWXHHa/trwKZOYm+WuDvEogID0lMGBqDsG
# 2RtaJx4o9AEzy5IClH4Gj8xX3eSWUm0Zdl4N+O/y41kC0fiowMgAhW9Om6ls7x7U
# CUzQ/GNI+WNkgZ0gqldszR0lbbOPmlH5FIbCkvhgF0t4+V1IGAO0jDaIO+jZ7LOZ
# dNZxF+7Bw3WMpGIc7kCha0+9F1U2Xl9ubUgX8t1WnM2HdSUiP/cDhqmxVOdjcq5b
# ANaopsTobLnbOz8aPozt0Y1f5AvgBDqFWlw3Zop7HNz7ZQQlYf7IGJ6PQFMpm5Uk
# ZnntYMJZ5WSdLohyiPathxYGVjNdMjxuYFbdKa15yRYtVsZpoPgR/wIDAQABo4IB
# NjCCATIwHQYDVR0OBBYEFBRbzvKNXjXEgiEGTL6hn3TS/qaqMB8GA1UdIwQYMBaA
# FJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3Rh
# bXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUH
# MAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9z
# b2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggIBAMpLlIE3
# NSjLMzILB24YI4BBr/3QhxX9G8vfQuOUke+9P7nQjTXqpU+tdBIc9d8RhVOh3Ivk
# y1D1J4b1J0rs+8ZIlka7uUY2WZkqJxFb/J6Wt89UL3lH54LcotCXeqpUspKBFSer
# Q7kdSsPcVPcr7YWVoULP8psjsIfpsbdAvcG3iyfdnq9r3PZctdqRcWwjQyfpkO7+
# dtIQL63lqmdNhjiYcNEeHNYj9/YjQcxzqM/g7DtLGI8IWs/R672DBMzg9TCXSz1n
# 1BbGf/4k3d48xMpJNNlo52TcyHthDX5kPym5Rlx3knvCWKopkxcZeZHjHy1BC4wI
# dJoUNbywiWdtAcAuDuexIO8jv2LgZ6PuEa1dAg9oKeATtdChVtkkPzIb0Viux24E
# ugc7e9K5CHklLaO6UZBzKq54bmyE3F3XZMuhrWbJsDN4b6l7krTHlNVuTTdxwPMq
# Yzy3f26Jnxsfeh7sPDq37XEL5O7YXTbuCYQMilF1D+3SjAiX6znaZYNI9bRNGohP
# qQ00kFZj8xnswi+NrJcjyVV6buMcRNIaQAq9rmtCx7/ywekVeQuAjuDLP6X2pf/x
# dzvoSWXuYsXr8yjZF128TzmtUfkiK1v6x2TOkSAy0ycUxhQzNYUA8mnxrvUv2u7p
# pL4pYARzcWX5NCGBO0UViXBu6ImPhRncdXLNMIIHcTCCBVmgAwIBAgITMwAAABXF
# 52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2Vy
# dGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMw
# MTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZI
# hvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfS
# qWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893
# MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWEC
# esSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W
# 7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWY
# bWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdb
# Z2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn42
# 7DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1D
# TsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12Nv
# DMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLb
# JbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3
# tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQB
# gjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D
# 9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9z
# aXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoA
# UwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQY
# MBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6
# Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1
# dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Ge
# ckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQY
# Iu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY
# 3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09
# J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tu
# PywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJv
# EKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lU
# ZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQ
# THa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8
# vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAn
# Qj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUF
# EMFxBmoQtB1VM1izoXBm8qGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQg
# T3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046
# ODk3QS1FMzU2LTE3MDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNl
# cnZpY2WiIwoBATAHBgUrDgMCGgMVAFuoev9uFgqO1mc+ghFQHi87XJg+oIGDMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQAC
# BQDm3lTBMCIYDzIwMjIwOTI4MDkwNjA5WhgPMjAyMjA5MjkwOTA2MDlaMHcwPQYK
# KwYBBAGEWQoEATEvMC0wCgIFAObeVMECAQAwCgIBAAICA6oCAf8wBwIBAAICEhEw
# CgIFAObfpkECAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgC
# AQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBKw2TMYacuSrTO
# wpf7AHpOSbi0EqipM31qd3WKIyh/ccp90Rr0WnIT4KBpfiGwkh43k2lDcFWqWCYC
# u1WQINqVipO/qbaHbBlCqhferGKq5HI7JTpJQLQLZhZqsJEuCeidA9yfLTHXHBCj
# nNMqQsyjVJKreJ9VPoiq3dkSJd7O8zGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABqwkJ76tj1OipAAEAAAGrMA0GCWCGSAFl
# AwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcN
# AQkEMSIEIIgA0BjVf7xGrRYg9dP1MGHd60+JNP2Ph1fFRINVvmONMIH6BgsqhkiG
# 9w0BCRACLzGB6jCB5zCB5DCBvQQgDhyv+rCFYBFUlQ9wK75OjskCr0cRRysq2lM2
# zdfwClcwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AasJCe+rY9ToqQABAAABqzAiBCDCcmmrUZhyvXQx/S49G1iJCKy05dlhENcslXRX
# 5OYYEzANBgkqhkiG9w0BAQsFAASCAgAZAG0NqjSIYhFRozPMv1mUMuHIuOFrzd1H
# k2KTypTi4y9dx2BLhW28Mk/7H6vvkcCnZNsyRtbeC35U8nd9peSG8cwyighGSDoe
# xJVbYr5ipml9xW36OX9763iKQcjCSRBJL+ZukC7vdW6bW7zh7dR9HsE0CIq8+TDY
# zFxRuAPcnOd215sSXuxy4hikaa2FziQJQUL649jWCtzeCdSuj3NV7ohCT609+gZ/
# PAjmAJnQTz4ZK8DMUiwc/RBl8HPScFhk6MocMfMO3EAJdPjNkxnQNGiwIbWt9Utx
# ZZSsS+q6VYXzduYGDTJ+8c300d7lumak9KnT3n7AZAqzK0RAWqfZPR73typeo2Dy
# CGYERMj66ilxINms88OYl7ieNxzyY5PHrPUL/RJZIoWmn5i+slFIEr4AHJ7liECw
# PlwzmuLSpGFEibHMZ5djKOkOyLrywXKdMEGvaa2E4wO9JOw0a6ZacC8ivzKxN67t
# 4lCse5dIBZ07OdIx3tpwVHIN3EPIbJ/aWIm181rwEd7R9gauoVaThvJgdjb8NAuZ
# T3CjiKtmaEL+AKIJVeSGpRMcjgOSq6XplmZEqrU8IlfDMlC/LgdKu2EesuPoQm2Z
# FaTWzfvgErf+8+2CrZMsquFbv/mhnLFjhxB583EysXPFisczvpf8nCA2yL61VHel
# 8ZZae+zcUA==
# SIG # End signature block
